package umkm;

public class TransaksiPenjualan {

    public TransaksiPenjualan() {
        //....
    }

    public void tambahBarang(Barang barang, int jumlah) {
        // Implementasi penambahan barang ke daftar belanja
    }

    public void hapusBarang(int nomorBarang) {
        // Implementasi penghapusan barang dari daftar belanja
    }

    public void bayar(int nomorTransaksi, String namaPembeli) {
        // Implementasi pembayaran
    }
}
